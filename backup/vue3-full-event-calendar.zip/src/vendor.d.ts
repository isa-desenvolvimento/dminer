declare module 'vidie'
declare module 'alga-vue'