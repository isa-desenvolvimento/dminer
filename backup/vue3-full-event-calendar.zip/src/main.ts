import { createApp } from 'vue'
import App from './App.vue'
import 'alga-css/dist/alga-v1.min.css'

createApp(App).mount('#app')
